# Kraanzu's Dotfiles :)

Dotfiles for my qtile setup :)

## Setup
```bash
git clone https://github.com/kraanzu/.dotfiles.git ~/.dotfiles
cd ~/.dotfiles/
bash setup.sh
```

## A screenshot of the desktop

![screen](https://user-images.githubusercontent.com/97718086/192107951-c90b29aa-ca58-4fd4-ab6c-33dd070c4efb.png)
