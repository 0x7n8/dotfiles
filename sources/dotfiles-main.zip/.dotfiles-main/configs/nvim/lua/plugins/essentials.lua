-- Essensial plugins which many other plugins depend on

return {
	"nvim-lua/plenary.nvim",
	"mfussenegger/nvim-dap",
}
