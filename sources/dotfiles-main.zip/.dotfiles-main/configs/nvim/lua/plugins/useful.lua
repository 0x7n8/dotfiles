return {
	{ "preservim/tagbar", cmd = "TagbarToggle" },
}
